<?php



if (!defined('AGENCY_MODULE_SCREEN_NAME')) {
    define('AGENCY_MODULE_SCREEN_NAME', 'agency');
}
