<?php

namespace Botble\Agency\Repositories\Eloquent;

use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;
use Botble\Agency\Repositories\Interfaces\AgentInterface;

class AgentRepository extends RepositoriesAbstract implements AgentInterface
{
}
