<?php

namespace Botble\Agency\Repositories\Eloquent;

use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;
use Botble\Agency\Repositories\Interfaces\AgencyInterface;

class AgencyRepository extends RepositoriesAbstract implements AgencyInterface
{
}
