<?php

namespace Botble\Agency\Repositories\Caches;

use Botble\Support\Repositories\Caches\CacheAbstractDecorator;
use Botble\Agency\Repositories\Interfaces\AgencyInterface;

class AgencyCacheDecorator extends CacheAbstractDecorator implements AgencyInterface
{

}
