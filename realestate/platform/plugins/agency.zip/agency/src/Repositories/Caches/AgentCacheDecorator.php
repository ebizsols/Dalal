<?php

namespace Botble\Agency\Repositories\Caches;

use Botble\Support\Repositories\Caches\CacheAbstractDecorator;
use Botble\Agency\Repositories\Interfaces\AgentInterface;

class AgentCacheDecorator extends CacheAbstractDecorator implements AgentInterface
{

}
