<?php

namespace Botble\Agency\Repositories\Interfaces;

use Botble\Support\Repositories\Interfaces\RepositoryInterface;

interface AgencyInterface extends RepositoryInterface
{
}
