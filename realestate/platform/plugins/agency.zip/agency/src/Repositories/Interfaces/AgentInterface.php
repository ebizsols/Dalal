<?php

namespace Botble\Agency\Repositories\Interfaces;

use Botble\Support\Repositories\Interfaces\RepositoryInterface;

interface AgentInterface extends RepositoryInterface
{
}
