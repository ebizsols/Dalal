<?php

return [
    'name'     => 'Agencies',
    'create'   => 'New Agency',
    'edit'     => 'Edit Agency',
    'assignagency'=>'Assign New Agent',
    'location' => 'Location',
    'salary'   => 'Salary',
];
